package com.psgsft.test;

public class RoomType {
	int id;
String Cot;
String Facilities;
public RoomType() {
	// TODO Auto-generated constructor stub
}
public String getCot() {
	return Cot;
}
public String getFacilities() {
	return Facilities;
}
public int getId() {
	return id;
}
}
