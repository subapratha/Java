package com.psgsft.test;

public class Services {
	int id;
String Food;
String Durationoftheday;
public Services() {
	// TODO Auto-generated constructor stub
}
public String getDurationoftheday() {
	return Durationoftheday;
}
public String getFood() {
	return Food;
}
}
